package com.learning.spring.checklis_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChecklisApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChecklisApiApplication.class, args);
	}

}
